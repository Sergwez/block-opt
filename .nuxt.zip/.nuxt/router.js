import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7120160f = () => interopDefault(import('..\\pages\\admin.vue' /* webpackChunkName: "pages/admin" */))
const _4b8cbb14 = () => interopDefault(import('..\\pages\\blocks.vue' /* webpackChunkName: "pages/blocks" */))
const _36e5a17c = () => interopDefault(import('..\\pages\\bricks.vue' /* webpackChunkName: "pages/bricks" */))
const _1213de7a = () => interopDefault(import('..\\pages\\contacts.vue' /* webpackChunkName: "pages/contacts" */))
const _09586529 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _264f56fe = () => interopDefault(import('..\\pages\\work.vue' /* webpackChunkName: "pages/work" */))
const _3fb0c212 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/admin",
    component: _7120160f,
    name: "admin"
  }, {
    path: "/blocks",
    component: _4b8cbb14,
    name: "blocks"
  }, {
    path: "/bricks",
    component: _36e5a17c,
    name: "bricks"
  }, {
    path: "/contacts",
    component: _1213de7a,
    name: "contacts"
  }, {
    path: "/login",
    component: _09586529,
    name: "login"
  }, {
    path: "/work",
    component: _264f56fe,
    name: "work"
  }, {
    path: "/",
    component: _3fb0c212,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
