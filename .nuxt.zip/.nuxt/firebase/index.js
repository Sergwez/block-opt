import createApp from './app.js'

import authService from './service.auth.js'
import firestoreService from './service.firestore.js'

const appConfig = {"apiKey":"AIzaSyBQIt60f1PjSRGqYG78sdUB1fJ5o22ykMY","authDomain":"['blockopt-a236b.firebaseapp.com']","projectId":"blockopt-a236b","storageBucket":"blockopt-a236b.appspot.com","messagingSenderId":"55558793227","appId":"1:55558793227:web:d4e8787e1f1a9b6ea3ff0e"}

export default async (ctx, inject) => {
  let firebase, session
  let firebaseReady = false

  const fire = {
    async appReady() {
      if (!firebaseReady) {
        ({ firebase, session } = await createApp(appConfig, ctx))
        firebaseReady = true;

        forceInject(ctx, inject, "fireModule", firebase)
      }
      return session
    },
    async ready() {
      await fire.appReady()

      let servicePromises = []

      if (process.server) {
        servicePromises = [
        fire.authReady(),
        fire.firestoreReady(),

        ]
      }

      if (process.client) {
        servicePromises = [
        fire.authReady(),
        fire.firestoreReady(),

        ]
      }

      await Promise.all(servicePromises)
      return session
    }
  }

  if (process.server) {
  fire.auth = null
  fire.authReady = async () => {
    if (!fire.auth) {
      await fire.appReady()
      fire.auth = await authService(session, firebase, ctx, inject)
    }

    return fire.auth
  }

  fire.firestore = null
  fire.firestoreReady = async () => {
    if (!fire.firestore) {
      await fire.appReady()
      fire.firestore = await firestoreService(session, firebase, ctx, inject)
    }

    return fire.firestore
  }
  }

  if (process.client) {
    fire.auth = null
    fire.authReady = async () => {
      if (!fire.auth) {
        await fire.appReady()
        fire.auth = await authService(session, firebase, ctx, inject)
      }

      return fire.auth
    }

    fire.firestore = null
    fire.firestoreReady = async () => {
      if (!fire.firestore) {
        await fire.appReady()
        fire.firestore = await firestoreService(session, firebase, ctx, inject)
      }

      return fire.firestore
    }
  }

  inject('fire', fire)
  ctx.$fire = fire
}

function forceInject (ctx, inject, key, value) {
  inject(key, value)
  const injectKey = '$' + key
  ctx[injectKey] = value
  if (typeof window !== "undefined" && window.$nuxt) {
  // If clause makes sure it's only run when ready() is called in a component, not in a plugin.
    window.$nuxt.$options[injectKey] = value
  }
}